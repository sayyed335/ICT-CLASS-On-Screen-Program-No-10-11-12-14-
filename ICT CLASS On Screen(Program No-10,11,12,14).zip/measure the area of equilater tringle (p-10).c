#include<stdio.h>
#include<math.h>
void main(){
float a,area;
printf("the length of arm:");
scanf("%f",&a);
area=((a*a)*sqrt(3))/4; ///or pow(a,2),here Base= a & power = 2
printf("area of equilateral triangle:%.3f",area);}
