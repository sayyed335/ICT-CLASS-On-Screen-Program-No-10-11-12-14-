#include<stdio.h>
#include<math.h>
void main()
{
    float a,b,area;
    printf("enter the value of equal arm :");
    scanf("%f",&a);
    printf("the value of other arm:"); ///value will less than "a" variable
    scanf("%f",&b);
    area=(b*sqrt(a*a-b*b)/4); ///equation
    printf("area of isosceles triangle is %.2f\n",area)
    ;
}
