#include<stdio.h>
void main()
{
    float a,b,area;
    printf("Enter the base :");
    scanf("%f",&a);
    printf("enter the height :");
    scanf("%f",&b);
    area=(a*b)/2;
    printf("The area of triangle is %.3f\n",area);
}
