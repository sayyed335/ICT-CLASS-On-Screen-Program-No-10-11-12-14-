#include<stdio.h>
void main()
{
    float d,v,t;
    printf("insert velocity in (m/s) :");
    scanf("%f",&v);
    printf("insert time in (Second) :");
    scanf("%f",&t);
    d=v*t;///calculation
    printf("distance= %.3f meter",d);
}
